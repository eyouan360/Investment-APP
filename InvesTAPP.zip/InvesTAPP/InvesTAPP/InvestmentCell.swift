//
//  InvestmentCell.swift
//  InvesTAPP
//
//  Created by User on 12/2/17.
//  Copyright © 2017 Zerocool. All rights reserved.
//

import UIKit


class InvestmentCell: UITableViewCell {
    
    
  
    
    
    @IBOutlet weak var banknameLabel: UILabel!
    
    @IBOutlet weak var startingamountLabel: UILabel!
    
    @IBOutlet weak var mytenureLabel: UILabel!
    
    @IBOutlet weak var futureamountLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        banknameLabel.adjustsFontForContentSizeCategory = true
        startingamountLabel.adjustsFontForContentSizeCategory = true
        mytenureLabel.adjustsFontForContentSizeCategory = true
        futureamountLabel.adjustsFontForContentSizeCategory = true
    }
    
    
    
}
