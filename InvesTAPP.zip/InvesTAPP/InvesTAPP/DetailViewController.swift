//
//  DetailViewController.swift
//  InvesTAPP
//
//  Created by User on 12/2/17.
//  Copyright © 2017 Zerocool. All rights reserved.
//

import UIKit

enum AddOrEdit {
    case add
    case edit
}


let numberFormatter: NumberFormatter = {
    let formatter = NumberFormatter()
    formatter.numberStyle = .decimal
    formatter.minimumFractionDigits = 2
    formatter.maximumFractionDigits = 2
    return formatter
}()


let dateFormatter: DateFormatter = {
    let formatter = DateFormatter()
    formatter.dateStyle = .medium
    formatter.timeStyle = .none
    return formatter
}()


class DetailViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
   
    
    
    var currentAmount: Double!
    var investmentStore: InvestmentStore!
    var investment: Investment!
    var bankRateOne = 3.3, bankRateTwo = 6.7, bankRateThree = 2.5, bankRateFour = 8.2
    var bankRateSelected = String()
    var addorEdit: AddOrEdit? = .edit
    
    
   
    
    
    
    
    
    
    
    
    @IBAction func saveButton(_ sender: UIButton) {
        
        // save the data from the screen to the investment (anInvestment)
        var okToSave: Bool = true
        switch addorEdit! {
        case .add:
            guard
                let bankName = bankTextBox.text,
                !bankName.isEmpty
                else {
                    return
            }
            var amt: Double
            let amtText = amountField.text
            //let value = numberFormatter.number(from: amtText)
            
           // amt = (value)!.doubleValue
            
            okToSave = investmentStore.createInvestment(bankName: bankTextBox.text ?? "", startingBalance: amtText!, futureAmount: "\(currentAmount!)", myTenure: tenureTextBox.text!) ? true: false
            
            break
        case .edit:
            
            let labelAmount = amountLabel.text
            let startAmount = amountField.text
            let thistenure = tenureTextBox.text
            let mybank = bankTextBox.text
            
            investment.bankName = mybank!
            investment.futureAmount = "\(currentAmount!)"
            investment.startingBalance = "\(startAmount!)"
            investment.myTenure = thistenure!
        }
        
        if okToSave {
            self.performSegue(withIdentifier: "unwindToInvestments", sender: self)
        } else {
            
            let alertController = UIAlertController (
                title: "Alert",
                message: "An Investment exist"
                ,
                preferredStyle: UIAlertControllerStyle.alert
            )
            
            let okayAction = UIAlertAction(title: "OK", style: .default)
            { (action) in
                
            }
            alertController.addAction(okayAction)
            
            self.present(alertController, animated: true) {
                
            }
            
        }
       
    }  // end button function
        
        
    
    
   /* @IBAction func amountTextBox(_ sender: UITextField) {
        let digits = sender.text?.lowercased() ?? "0"
        sender.text = "\(digits)" + ".00"
        
    }
    */
  
    
    @IBOutlet weak var amountField: UITextField!
    @IBOutlet weak var tenureTextBox: UITextField!
    @IBOutlet weak var bankTextBox: UITextField!
    @IBOutlet weak var amountLabel: UILabel!
    
    @IBOutlet weak var bankDropDowm: UIPickerView!
     @IBOutlet weak var tenureDropDown: UIPickerView!
    
    var list = [String]()
    
    var tenArray = [String]()
    
    var monthOptions = [Int]()
    
   
    @IBOutlet weak var dateLabel: UILabel!
    
  
    
    
    func getvalueSaved(TextField: UITextField) {
        var myBank = bankTextBox.text
        
    }
    
    
    
    
    
    @IBAction func getNewAmount(_ sender: UIButton) {
        var newAmountResult:Double = Double(amountField.text!)!
        var bankRateValue = Double()
        
        var newBankRate: String = bankTextBox.text!
        
        var newTenureRate: String = tenureTextBox.text!
        
        
        
       // var totalbankRateOne = Double()
        
       // totalbankRateOne = Double(newBankRate)!
        
        //let string = NSString(string: newBankRate)
        //string.doubleValue
        
       
        
         var totalbankRateOne = (newBankRate as NSString).doubleValue
        
         var totaltenureRateOne = (newTenureRate as NSString).intValue
       
        
        //print(totalbankRateOne)
        
         //totalbankRateOne = 3.5
        
        //double = 3.5
        
        
        
        
    switch newBankRate {
        case "JPMorgan Chase - 3.3/month":
            totalbankRateOne = 3.3
        case "Bank of America - 6.7/month":
            totalbankRateOne = 0.067
        case "Wells Fargo - 2.5/month":
            totalbankRateOne = 2.5
        case "Citigroup - 8.2/month":
            totalbankRateOne = 8.2
        default:
            totalbankRateOne = 0
        }

       
    switch newTenureRate {
    case "90 days":
        totaltenureRateOne = 3
    case "6 months":
        totaltenureRateOne = 6
    case "1 year":
        totaltenureRateOne =  12
    case "5 years":
        totaltenureRateOne =  60
        default:
            totaltenureRateOne = 0
        }
    
        
        
        for _ in 1...totaltenureRateOne {
            
            newAmountResult +=   newAmountResult * totalbankRateOne
        }
        
      //  if (newBankRate == "Bank of America - 6.7/month"){
        //   totalbankRateOne = 3.5
        //}
        
        
       // if let total = Double(newAmountResult) {
       //     bankRateValue = total * totaltenureRateOne
            
            
        //}

        amountLabel.text = "Your Future Amount is : \(newAmountResult.round(to: 2))"
        currentAmount = newAmountResult.round(to: 2)
        
    }
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
      let dateOfCreation = Date() as NSDate
        dateLabel.text = String(describing: dateOfCreation)
        
        var dateFinal = dateLabel.text
        
        amountField.delegate = self
        amountField.addTarget(self, action: #selector(self.textFieldChanged), for: UIControlEvents.editingChanged)
        
        
       
      
        
        
       let pickerView = UIPickerView()
        
        pickerView.tag = 1
        
        let pickerView2 = UIPickerView()
        
        pickerView.delegate = self
        pickerView2.delegate = self
        
        bankTextBox.inputView = pickerView
        tenureTextBox.inputView = pickerView2
        
        list = ["JPMorgan Chase - 3.3/month", "Bank of America - 6.7/month", "Wells Fargo - 2.5/month", "Citigroup - 8.2/month"]
        
        tenArray = ["90 days", "6 months", "1 year", "5 years"]
        
        monthOptions = [3, 6, 12, 60]
    }
    


    
    
    
    
    @objc func textFieldChanged(textField: UITextField) {
        
        var text = amountField.text!.replacingOccurrences(of: ".00", with: "")
        text = text + ".00"
        amountField.text = text
    }
    
    @objc func doneClicked() {
        
        view.endEditing(true)
    }
    
    
    
   
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent Component: Int) -> Int {
        
        if (pickerView.tag == 1){
            return list.count
        } else {
            return tenArray.count
        }
        
        
    }
    
    
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
       //  if let bankTextBox = self.view.viewWithTag(1) as? UITextField {
        //}
        if (pickerView.tag == 1){
             return "\(list[row])"
        } else {
           return "\(tenArray[row])"
        }
        
        
        
       
    }
    
    
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
       
        var tenureSelected = String()
        
       if (pickerView.tag == 1){
        self.bankTextBox.text = self.list[row]
        self.bankDropDowm.isHidden = true
        self.view.endEditing(true)

       
        
       // let bankRateValue = Int(list.insert(3, at: 0))
        
      /*  var convert1 = Double(list[0])
        var convert2 = Double(list[1])
        var convert3 = Double(list[2])
        var convert4 = Double(list[3])
        
        convert1 = bankRateOne
        convert2 = bankRateTwo
        convert3 = bankRateThree
        convert4 = bankRateFour  */
        
        
        
        
        
         bankRateSelected = list[row] as String
         print(bankRateSelected)
        
        
        
        
        
        }
        
        
        
        else{
        
            self.tenureTextBox.text = self.tenArray[row]
            self.tenureDropDown.isHidden = true
            self.view.endEditing(true)
        
        tenureSelected = tenArray[row] as String
        
        print(tenureSelected)
        
        
        }
        
       // var convert1 = Double(list[0])
       // convert1 = bankRateOne
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
       view.endEditing(true)
    }
    
    
    
   func textFieldDidBeginEditing(textField: UITextField, textField2: UITextField) {
        
        if textField == self.bankTextBox {
            self.bankDropDowm.isHidden = false
            textField.endEditing(true)
        }
        
            if textField2 == self.tenureTextBox {
           self.tenureDropDown.isHidden = false
            textField2.endEditing(true)
            }
    
   
        }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let rightBarButton = UIBarButtonItem(title: "Save", style: UIBarButtonItemStyle.plain, target: self, action: #selector(DetailViewController.saveButton(_:)))
        self.navigationItem.rightBarButtonItem = rightBarButton
        
        
        let toolBar = UIToolbar()
        toolBar.sizeToFit()
        
        let doneButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.done, target: self, action: #selector(self.doneClicked))
        
        toolBar.setItems([doneButton], animated: true)
        
        amountField.inputAccessoryView = toolBar
        
        switch addorEdit! {
        case .add:
            bankTextBox.becomeFirstResponder()
            break
        case .edit:
            bankTextBox.text = investment.bankName
            amountField.text = investment.startingBalance
            tenureTextBox.text = investment.myTenure
           amountLabel.text = investment.futureAmount
           
        }
        
    }
    
    
    @objc func saveBarButtonItmeTapped(_ sender: UIBarButtonItem) {
        // save the data from the screen to the investment (anInvestment)
        var okToSave: Bool = true
       switch addorEdit! {
        case .add:
            guard
                let bankName = bankTextBox.text,
                !bankName.isEmpty
                else {
                    return
            }
            var amt: Double
            let amtText = amountField.text
            let value = "\(amtText)"
            
            amt = Double(value)!
            
            okToSave = investmentStore.createInvestment(bankName: bankTextBox.text ?? "", startingBalance: amtText!, futureAmount:"\(currentAmount!)", myTenure: tenureTextBox.text!) ? true: false
            
            break
        case .edit:
            
            let labelAmount = amountLabel.text
            let startAmount = amountField.text
            let thistenure = tenureTextBox.text
            let mybank = bankTextBox.text
            
            investment.bankName = (numberFormatter.number(from: mybank!) as? String)!
            investment.futureAmount = "\(currentAmount)"
            investment.startingBalance = "\(startAmount!)"
            investment.myTenure = (numberFormatter.number(from: thistenure!) as? String)!
            }
        
        if okToSave {
            self.performSegue(withIdentifier: "unwindToInvestments", sender: self)
        } else {
            
            let alertController = UIAlertController (
                title: "Alert",
                message: "An Investment exist"
                ,
                preferredStyle: UIAlertControllerStyle.alert
            )
            
            let okayAction = UIAlertAction(title: "OK", style: .default)
            { (action) in
                
            }
            alertController.addAction(okayAction)
            
            self.present(alertController, animated: true) {
                
            }
            
        }
        
    }
    
   
    
    
    // amountField.text = investment.name
    // tenureTextBox.text = investment.serialNumber
    //bankTextBox.text = "\(investment.valueInDollars)"
    // dateLabel.text = dateFormatter.string(from: investment.dateCreated)
   
    
    
    
       /* if(bankRateSelected == list[0]) {
    
    var convert1 = Double(list[0])
    
    convert1 = bankRateOne
    
    print(convert1)
    }
    */
    
}





extension Double {
    func round(to places: Int) -> Double {
        let divisor = pow(10.0, Double(places))
        return Darwin.round(self * divisor) / divisor
    }
}




