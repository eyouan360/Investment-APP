//
//  Investment.swift
//  InvesTAPP
//
//  Created by User on 12/2/17.
//  Copyright © 2017 Zerocool. All rights reserved.
//

import UIKit

class Investment: NSObject, NSCoding {
    
    
   
    
    var bankName: String
    var startingBalance: String
    var futureAmount: String
    var myTenure: String
    let investmentKey: String?
    
    init(bankName: String, startingBalance: String,  futureAmount: String, myTenure: String) {
        self.bankName = bankName
        self.startingBalance = startingBalance
        self.futureAmount = futureAmount
        self.myTenure = myTenure
        self.investmentKey = UUID().uuidString
        
        super.init()
        
    }
    
    func encode(with aCoder: NSCoder) {
        aCoder.encode(bankName, forKey: "bankName")
        aCoder.encode(startingBalance, forKey: "startingBalance")
        aCoder.encode(futureAmount, forKey: "investmentKey")
        aCoder.encode(investmentKey, forKey: "investmentKey")
        
        aCoder.encode(myTenure , forKey: "myTenure")
    }
    
    required init?(coder aDecoder: NSCoder) {
        bankName = aDecoder.decodeObject(forKey: "bankName") as! String
        startingBalance = aDecoder.decodeObject(forKey: "startingBalance") as! String
        futureAmount = aDecoder.decodeObject(forKey: "futureAmount") as! String
        myTenure = aDecoder.decodeObject(forKey: "myTenure") as! String
        
        investmentKey = aDecoder.decodeObject(forKey: "investmentKey") as! String
        
        super.init()
    }
 
    
}
