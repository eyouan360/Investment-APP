//
//  InvestmentStore.swift
//  InvesTAPP
//
//  Created by User on 12/2/17.
//  Copyright © 2017 Zerocool. All rights reserved.
//

import UIKit


class InvestmentStore {
    
    var allInvestments = [Investment]()
    
    let investmentArchiveURL: URL = {
        let documentsDirectories = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        var documentDirectory = documentsDirectories.first!
        return documentDirectory.appendingPathComponent("investments.archive")
        
    }()
    
   
    
    func savedChanges() -> Bool {
        print("Saving investments to: \(investmentArchiveURL.path)")
        return NSKeyedArchiver.archiveRootObject(allInvestments, toFile: investmentArchiveURL.path)
    }
    
    func moveInvestment(from fromIndex: Int, to toIndex: Int) {
        if fromIndex == toIndex {
            return
        }
        
        // Get reference to object being moved so you can re-insert it
        let movedInvestment = allInvestments[fromIndex]
        
        // Remove item from array
        allInvestments.remove(at: fromIndex)
        
        // Insert item in array at new location
        allInvestments.insert(movedInvestment, at: toIndex)
    }
    
    
    @discardableResult func createInvestment(bankName: String, startingBalance: String, futureAmount: String, myTenure: String) -> Bool {
       
        let newInvestment = Investment(bankName: bankName, startingBalance: "\(startingBalance)", futureAmount: "\(futureAmount)" , myTenure: myTenure)
        
        allInvestments.append(newInvestment)
        
        return true
    }
    
    func removeInvestment(_ investment: Investment) {
        if let index = allInvestments.index(of: investment) {
            allInvestments.remove(at: index)
        }
    }
    
    
    
}
